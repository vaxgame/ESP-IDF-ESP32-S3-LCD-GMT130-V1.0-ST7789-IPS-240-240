/*
ESP-IDF V5.3.2
ESP32-S3
1.3 inch TFT Module
240×240
ST7789
 */
#include "driver/spi_master.h" // SPI驅動程式的標頭檔
#include "driver/gpio.h"       // GPIO驅動程式的標頭檔
#include "esp_log.h"           // 用於日誌輸出
#include "freertos/FreeRTOS.h" // FreeRTOS必要檔案
#include "freertos/task.h"     // FreeRTOS任務管理
#include <string.h>

// 定義引腳配置
#define GMT_SCK 4  // SPI Serial Clock
#define GMT_SDA 5  // SPI Serial Data (MOSI)
#define GMT_RES 6  // 顯示器 Reset 引腳
#define GMT_DC 7   // 顯示器 Data/Command 控制引腳
#define GMT_BLK 15 // 背光控制引腳 (PWM 控制)

// 定義 ST7789 命令
#define CMD_SWRESET 0x01 // 軟體重置
#define CMD_SLPOUT 0x11  // 復原模式
#define CMD_DISPON 0x29  // 打開顯示
#define CMD_CASET 0x2A   // 設定列地址
#define CMD_RASET 0x2B   // 設定行地址
#define CMD_RAMWR 0x2C   // 寫入記憶體數據
#define CMD_MADCTL 0x36  // 記憶體數據控制
#define CMD_COLMOD 0x3A  // 設定像素格式

// SPI 設定參數
#define SPI_HOST_ID SPI2_HOST // ESP32-S3 支援的 SPI2 作為主機

static const char *TAG = "ST7789"; // 日誌標籤

spi_device_handle_t spi; // SPI裝置控制句柄

// 功能：傳送命令到 ST7789
void st7789_send_cmd(const uint8_t cmd)
{
    spi_transaction_t t = {
        .length = 8,       // 命令為8位元長度
        .tx_buffer = &cmd, // 指向傳送的命令
        .user = (void *)0  // 標記此為命令傳送
    };
    gpio_set_level(GMT_DC, 0); // DC = 0，進入命令模式
    ESP_ERROR_CHECK(spi_device_transmit(spi, &t));
}

// 功能：傳送數據到 ST7789
void st7789_send_data(const uint8_t *data, int len)
{
    spi_transaction_t t = {
        .length = len * 8, // 每個字節長度為8位元
        .tx_buffer = data, // 指向數據緩衝區
        .user = (void *)1  // 標記此為數據傳送
    };
    gpio_set_level(GMT_DC, 1); // DC = 1，進入數據模式
    ESP_ERROR_CHECK(spi_device_transmit(spi, &t));
}

// 功能：硬體重置 ST7789 顯示器
void st7789_reset(void)
{
    gpio_set_level(GMT_RES, 0); // 拉低 Reset 引腳
    vTaskDelay(pdMS_TO_TICKS(100));
    gpio_set_level(GMT_RES, 1); // 拉高 Reset 引腳，結束重置
    vTaskDelay(pdMS_TO_TICKS(100));
}

// 功能：設定顯示記憶體範圍
void st7789_set_address_window(uint16_t x0, uint16_t y0, uint16_t x1, uint16_t y1)
{
    uint8_t data[4];
    st7789_send_cmd(CMD_CASET); // 設定列地址
    data[0] = (x0 >> 8);
    data[1] = x0 & 0xFF;
    data[2] = (x1 >> 8);
    data[3] = x1 & 0xFF;
    st7789_send_data(data, 4);

    st7789_send_cmd(CMD_RASET); // 設定行地址
    data[0] = (y0 >> 8);
    data[1] = y0 & 0xFF;
    data[2] = (y1 >> 8);
    data[3] = y1 & 0xFF;
    st7789_send_data(data, 4);
}

// 功能：清除屏幕 (填充黑色)
void st7789_clear_screen(void)
{
    st7789_set_address_window(0, 0, 239, 239); // 設置全屏範圍
    st7789_send_cmd(CMD_RAMWR);                // 開始寫入數據
    uint8_t color_data[2] = {0xFF, 0xFF};      // 黑色
    for (int i = 0; i < 240 * 240; i++)
    {
        st7789_send_data(color_data, sizeof(color_data));
    }
}

// 功能：初始化 ST7789
void st7789_init(void)
{
    ESP_LOGI(TAG, "Initializing ST7789...");
    // 設定 GPIO 模式
    gpio_config_t io_conf = {
        .pin_bit_mask = (1ULL << GMT_RES) | (1ULL << GMT_DC) | (1ULL << GMT_BLK),
        .mode = GPIO_MODE_OUTPUT,
        .pull_up_en = GPIO_PULLUP_DISABLE,
        .pull_down_en = GPIO_PULLDOWN_DISABLE,
        .intr_type = GPIO_INTR_DISABLE};
    gpio_config(&io_conf);

    // 配置 SPI 參數
    spi_bus_config_t buscfg = {
        .mosi_io_num = GMT_SDA,
        .miso_io_num = -1, // 不使用 MISO
        .sclk_io_num = GMT_SCK,
        .quadwp_io_num = -1,
        .quadhd_io_num = -1,
        .max_transfer_sz = 240 * 240 * 2 // 最大傳輸大小
    };
    ESP_ERROR_CHECK(spi_bus_initialize(SPI_HOST_ID, &buscfg, SPI_DMA_CH_AUTO));

    spi_device_interface_config_t devcfg = {
        .clock_speed_hz = 40 * 1000 * 1000, // 10 MHz SPI 時鐘
        .mode = 3,                          // 修改為 SPI模式 3
        .spics_io_num = -1,                 // 不使用 CS (手動控制)
        .queue_size = 7,
    };
    ESP_ERROR_CHECK(spi_bus_add_device(SPI_HOST_ID, &devcfg, &spi));

    // 重置顯示器
    st7789_reset();

    // 初始化命令序列
    st7789_send_cmd(CMD_SWRESET); // 軟體重置
    vTaskDelay(pdMS_TO_TICKS(150));

    st7789_send_cmd(CMD_SLPOUT); // 復原模式
    vTaskDelay(pdMS_TO_TICKS(500));

    st7789_send_cmd(CMD_COLMOD); // 設置像素格式
    uint8_t colmod_data = 0x05;  // 16位色彩 (RGB565)
    st7789_send_data(&colmod_data, 1);

    st7789_send_cmd(CMD_MADCTL); // 設置記憶體存取控制
    uint8_t madctl_data = 0x02;  // 設置掃描方向 (上下左右)
    st7789_send_data(&madctl_data, 1);

    st7789_send_cmd(CMD_CASET); // 設置列地址範圍 (0 - 239)
    uint8_t caset_data[4] = {0x00, 0x00, 0x00, 0xEF};
    st7789_send_data(caset_data, 4);

    st7789_send_cmd(CMD_RASET); // 設置行地址範圍 (0 - 239)
    uint8_t raset_data[4] = {0x00, 0x00, 0x00, 0xEF};
    st7789_send_data(raset_data, 4);

    st7789_send_cmd(CMD_DISPON); // 開啟顯示
    vTaskDelay(pdMS_TO_TICKS(100));

    ESP_LOGI(TAG, "ST7789 Initialization complete!");
}

// 功能：填充整個畫面為指定顏色
void st7789_fill_screen(uint8_t high_byte, uint8_t low_byte)
{
    st7789_set_address_window(0, 0, 239, 239); // 設置全屏範圍
    st7789_send_cmd(CMD_RAMWR);                // 開始寫入數據
    uint8_t color_data[2] = {high_byte, low_byte};
    for (int i = 0; i < 240 * 240; i++)
    {
        st7789_send_data(color_data, sizeof(color_data));
    }
}

// 主函數
void app_main(void)
{
    ESP_LOGI(TAG, "Starting ST7789 Example");

    // 初始化 ST7789 顯示器
    st7789_init();

    st7789_clear_screen(); // 清理屏幕
    // 背光控制 (PWM可選)
    gpio_set_level(GMT_BLK, 1); // 點亮背光
    while (1)
    {
        vTaskDelay(pdMS_TO_TICKS(100));
        // 測試畫面：填充單一顏色
        ESP_LOGI(TAG, "Filling screen with RED");
        st7789_fill_screen(0x07, 0xFF); // 紅色 (RGB565(0x07, 0xFF))
        vTaskDelay(pdMS_TO_TICKS(1000));

        ESP_LOGI(TAG, "Filling screen with GREEN");
        st7789_fill_screen(0xF8, 0x1F); // 綠色 (RGB565(0xF8, 0x1F))
        vTaskDelay(pdMS_TO_TICKS(1000));

        ESP_LOGI(TAG, "Filling screen with BLUE");
        st7789_fill_screen(0xFF, 0xE0); // 藍色 (RGB565(0xFF, 0xE0))
        vTaskDelay(pdMS_TO_TICKS(1000));

        ESP_LOGI(TAG, "Filling screen with WHITE");
        st7789_fill_screen(0x00, 0x00); // 白色 (RGB565(0x00, 0x00))
        vTaskDelay(pdMS_TO_TICKS(1000));

        ESP_LOGI(TAG, "Filling screen with YELLOW");
        st7789_fill_screen(0x00, 0x1F); // 黃色 (RGB565(0x00, 0x1F))
        vTaskDelay(pdMS_TO_TICKS(1000));

        ESP_LOGI(TAG, "Display test complete");
    }
}
